
import mqtt from '../../utils/mqtt.js';

const aliyunOpt = require('../../utils/aliyun/aliyun_connect.js');
const devicePubTopic = '/k19g7lmaIxi/WeChat/user/wechat'//设备发布Topic

const mpPubTopic = devicePubTopic
Page({
    //数据区域
  data: {
        client:null,
        Temp:0,//温度
        Humi:0,//湿度
        lightx:0,//光照强度
        AQI :0,//空气质量
        Led:false,//报警指示灯
        Buzzer:false,//报警开关
         //记录重连的次数
        reconnectCounts: 0,
    //MQTT连接的配置
    options: {
      protocolVersion: 4, //MQTT连接协议版本
      clean: false,
      reconnectPeriod: 1000, //1000毫秒，两次重新连接之间的间隔
      connectTimeout: 30 * 1000, //1000毫秒，两次重新连接之间的间隔
      resubscribe: true, //如果连接断开并重新连接，则会再次自动订阅已订阅的主题（默认true）
      clientId: '',
      password: '',
      username: '',
    },
    aliyunInfo: {
      productKey: 'k19g7lmaIxi', //阿里云连接的三元组 ，请自己替代为自己的产品信息!!
      deviceName: 'WeChat', //阿里云连接的三元组 ，请自己替代为自己的产品信息!!
      deviceSecret: '82e1d6857c23438e28d241f282569f2a', //阿里云连接的三元组 ，请自己替代为自己的产品信息!!
      regionId: 'cn-shanghai', //阿里云连接的三元组 ，请自己替代为自己的产品信息!!
    }
  },
  //函数区域
  onShow(){

  },
  onClick_connect: function() {
    var that = this
    //传进去三元组等信息，拿到mqtt连接的各个参数
    let clientOpt = aliyunOpt.getAliyunIotMqttClient({
      productKey: that.data.aliyunInfo.productKey,
      deviceName: that.data.aliyunInfo.deviceName,
      deviceSecret: that.data.aliyunInfo.deviceSecret,
      regionId: that.data.aliyunInfo.regionId,
      port: that.data.aliyunInfo.port,
    });
    //console.log("get data:" + JSON.stringify(clientOpt));
    //得到连接域名
    let host = 'wxs://'+clientOpt.host;
    this.setData({
      'options.clientId': clientOpt.clientId,
      'options.password': clientOpt.password,
      'options.username': clientOpt.username,
    })
    console.log("this.data.options host:" + host);
    console.log("this.data.options data:" + JSON.stringify(this.data.options));
    //开始连接
    this.data.client = mqtt.connect(host, this.data.options);
    this.data.client.on('connect', function(connack) {
      wx.showToast({
        title: '连接成功'
      })
    })
    
    //服务器下发消息的回调
    that.data.client.on("message", function(topic, payload) {
      console.log(" 收到 topic:" + topic + " , payload :" + payload)
      let dataFromDev={}
        try{
            dataFromDev=JSON.parse(payload)
            console.log(dataFromDev);
            that.setData({
                    Temp :dataFromDev.Temperature,
                    Humi:dataFromDev.Humidity,
                    lightx:dataFromDev.LightLux,//光照强度
                    AQI :dataFromDev.AQI,//空气质量
                    Led:dataFromDev.LightSwitch,//报警指示灯
                    Buzzer:dataFromDev.AlarmSwitch,//报警开关
            })
        }catch(error){
            console.log(error);
        }
    //   wx.showModal({
    //     content: " 收到topic:[" + topic + "], payload :[" + payload + "]",
    //     showCancel: false,
    //   });
    })
    //服务器连接异常的回调
    that.data.client.on("error", function(error) {
      console.log(" 服务器 error 的回调" + error)

    })
    //服务器重连连接异常的回调
    that.data.client.on("reconnect", function() {
      console.log(" 服务器 reconnect的回调")

    })
    //服务器连接异常的回调
    that.data.client.on("offline", function(errr) {
      console.log(" 服务器offline的回调")
    })
  },
  onClick_SubOne: function() {
    if (this.data.client && this.data.client.connected) {
      //仅订阅单个主题
      this.data.client.subscribe(' /k19g7lmaIxi/WeChat/user/wechat', function(err, granted) {
        if (!err) {
          wx.showToast({
            title: '订阅主题成功'
          })
        } else {
          wx.showToast({
            title: '订阅主题失败',
            icon: 'fail',
            duration: 2000
          })
        }
      })
    } else {
      wx.showToast({
        title: '请先连接服务器',
        icon: 'none',
        duration: 2000
      })
    }
  },
  onClick_SubMany: function() {

    if (this.data.client && this.data.client.connected) {
      //仅订阅多个主题
      this.data.client.subscribe({
        'Topic1': {
          qos: 0
        },
        'Topic2': {
          qos: 1
        }
      }, function(err, granted) {
        if (!err) {
          wx.showToast({
            title: '订阅多主题成功'
          })
        } else {
          wx.showToast({
            title: '订阅多主题失败',
            icon: 'fail',
            duration: 2000
          })
        }
      })
    } else {
      wx.showToast({
        title: '请先连接服务器',
        icon: 'none',
        duration: 2000
      })
    }
  },
  onClick_PubMsg: function() {
    if (this.data.client && this.data.client.connected) {
      this.data.client.publish(mpPubTopic, '{ "target":"MaxTemperature","value":50 }');
      wx.showToast({
        title: '发布成功'
      })
    } else {
      wx.showToast({
        title: '请先连接服务器',
        icon: 'none',
        duration: 2000
      })
    }
  },
  onClick_unSubOne: function() {
    if (this.data.client && this.data.client.connected) {
      this.data.client.unsubscribe('Topic1');
    } else {
      wx.showToast({
        title: '请先连接服务器',
        icon: 'none',
        duration: 2000
      })
    }
  },
  onClick_unSubMany: function() {
    if (this.data.client && this.data.client.connected) {
      this.data.client.unsubscribe(['Topic1', 'Topic2']);
    } else {
      wx.showToast({
        title: '请先连接服务器',
        icon: 'none',
        duration: 2000
      })
    }
  },

  onLedChange: function(event){
    const that =this
    console.log(event.detail.value);
    const sw=event.detail.value
    that.setData({Led:sw})
    if(sw)
    {
        if (this.data.client && this.data.client.connected) {
             this.data.client.publish(mpPubTopic, ' { "target":"LED","value":1}');
             wx.showToast({
                title: '下发指令成功'
              })
        }else {
            wx.showToast({
              title: '请先连接服务器',
              icon: 'none',
              duration: 2000
            })
          }
       
    }
    else
    {
        if (this.data.client && this.data.client.connected) {
            this.data.client.publish(mpPubTopic, ' { "target":"LED","value":0}');
            wx.showToast({
               title: '下发指令成功'
             })
       }else {
           wx.showToast({
             title: '请先连接服务器',
             icon: 'none',
             duration: 2000
           })
         }
    }
  },
  onBuzzerChange: function(event){
    const that =this
    console.log(event.detail.value);
    const sw=event.detail.value
    that.setData({Buzzer:sw})
    if(sw)
    {
        if (this.data.client && this.data.client.connected) {
             this.data.client.publish(mpPubTopic, '  { "target":"BUZZER","value":1 }');
             wx.showToast({
                title: '下发指令成功'
              })
        }else {
            wx.showToast({
              title: '请先连接服务器',
              icon: 'none',
              duration: 2000
            })
          }
       
    }
    else
    {
        if (this.data.client && this.data.client.connected) {
            this.data.client.publish(mpPubTopic, '   { "target":"BUZZER","value":0 }');
            wx.showToast({
               title: '下发指令成功'
             })
       }else {
           wx.showToast({
             title: '请先连接服务器',
             icon: 'none',
             duration: 2000
           })
         }
    }
  },
  formSubmit: function (e) {
    console.log('form发生了submit事件，携带数据为：', e.detail.value)
    if (this.data.client && this.data.client.connected) {
        
        this.data.client.publish(mpPubTopic,JSON.stringify(
            {
                "target":"MaxTemperature",
                "value":e.detail.value.MaxTemperature,
            }
        ) );
        wx.showToast({
          title: '发布成功'
        })
      } else {
        wx.showToast({
          title: '请先连接服务器',
          icon: 'none',
          duration: 2000
        })
      }
     
  },
  formSubmithumi: function (e) {
    console.log('form发生了submit事件，携带数据为：', e.detail.value)
    if (this.data.client && this.data.client.connected) {
        
        this.data.client.publish(mpPubTopic,JSON.stringify(
            {
                "target":"MaxHumidity",
                "value":e.detail.value.MaxHumidity,
            }
        ) );
        wx.showToast({
          title: '发布成功'
        })
      } else {
        wx.showToast({
          title: '请先连接服务器',
          icon: 'none',
          duration: 2000
        })
      }
     
  },

})