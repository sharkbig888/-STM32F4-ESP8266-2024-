// app.js
App({
    globalData: {
      userInfo: null
    },
    
    onLaunch: function () {
      // 登录
      wx.login({
        success: res => {
          if (res.code) {
            // 发起网络请求，将 res.code 发送到后台
            wx.request({
              url: 'http://127.0.0.1:3000', // 替换为你的 API 接口
              method: 'POST',
              data: {
                code: res.code
              },
              success: function (response) {
                // 处理返回的数据
                if (response.data && response.data.userInfo) {
                  this.globalData.userInfo = response.data.userInfo;
                }
              }.bind(this)
            });
          } else {
            console.error('登录失败！' + res.errMsg);
          }
        }
      });
    }
  });
  