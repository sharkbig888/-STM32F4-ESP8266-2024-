微信小程序连接阿里云接受STM32上传的数据，并下发指令控制STM32[如何基于物联网平台构建M2M设备间通信架构_物联网平台(IoT)-阿里云帮助中心](https://help.aliyun.com/zh/iot/use-cases/m2m-communication?spm=a2c4g.11186623.0.i9)



1.首先我们确保STM32已经连接上阿里云可以正常上传数据，接受阿里云下发的指令。

2.连接步骤

    a.我们在STM32那个产品下，新加一个设备

![eee2819f-5172-4f7f-a77b-9654b78b1caf](file:///C:/Users/SHARK/Pictures/Typedown/eee2819f-5172-4f7f-a77b-9654b78b1caf.png)

![0465cbd6-0c6a-4d32-b380-8ab978bdd383](file:///C:/Users/SHARK/Pictures/Typedown/0465cbd6-0c6a-4d32-b380-8ab978bdd383.png)

b.在产品下定义两个topic

![c17e3f62-6e5c-4cbf-aa5c-0caec3272eeb](file:///C:/Users/SHARK/Pictures/Typedown/c17e3f62-6e5c-4cbf-aa5c-0caec3272eeb.png)

c.进行STM32和WeChat的连接，通过阿里云的云产品流转，

我们返回旧版

![455fd828-699d-4844-81c7-bdf90fb84bb1](file:///C:/Users/SHARK/Pictures/Typedown/455fd828-699d-4844-81c7-bdf90fb84bb1.png)

![06e7a6f0-8a57-4238-8141-55c2a585fe12](file:///C:/Users/SHARK/Pictures/Typedown/06e7a6f0-8a57-4238-8141-55c2a585fe12.png)

新建两个规则

esp：负责将上传到云平台的数据转发到WeChat订阅的主题里面，

其中esp的数据来源为：STM32发布的主题，再这里我们使用SQL语句来过滤一下数据，SELECT deviceName() as deviceName, items.CurrentHumidity.value as Humidity, items.CurrentTemperature.value as Temperature, items.LightLux.value as LightLux,items.AlarmSwitch.value as AlarmSwitch, items.AQI.value as AQI,items.LightSwitch.value as LightSwitch FROM "/k19g7lmaIxi/device1/thing/event/property/post" WHERE

（[如何编写数据流转规则的SQL表达式_物联网平台(IoT)-阿里云帮助中心](https://help.aliyun.com/zh/iot/user-guide/sql-statements?spm=5176.11485173.console-base_help.dexternal.655f59af3QKG04#section-fgb-5bx-wdb)）

![5f556b81-2f66-4bd4-93fc-a09e23e69d6f](file:///C:/Users/SHARK/Pictures/Typedown/5f556b81-2f66-4bd4-93fc-a09e23e69d6f.png)

数据目的地为:微信小程序订阅的主题，（如果微信小程序订阅不上主题，可以开启代理订阅，使小程序被动订阅这个主题）

![b039e0dab2f749f9a62c7e71ae7d0b81](file:///C:/Users/SHARK/Pictures/Typedown/b039e0da-b2f7-49f9-a62c-7e71ae7d0b81.png?msec=1730089893770)

![1e3ba5699fe54c6e9612639e0b7bd1e8](file:///C:/Users/SHARK/Pictures/Typedown/1e3ba569-9fe5-4c6e-9612-639e0b7bd1e8.png?msec=1730089883011)

最后我们启动规则：这样 当STM32和小程序都连上云平台时，上传的数据就会依据规则自动发送到小程序里面；

d.微信小程序与阿里云的连接

    我们把刚刚创建好的设备的三元组复制下来，

![a3184e33-8cef-4a09-acd3-a7bdeb980e81](file:///C:/Users/SHARK/Pictures/Typedown/a3184e33-8cef-4a09-acd3-a7bdeb980e81.png)

    打开微信开发者工具，创建一个项目

![e85f915d-92fc-4297-8f55-4386d6d87f05](file:///C:/Users/SHARK/Pictures/Typedown/e85f915d-92fc-4297-8f55-4386d6d87f05.png)

我们需要添加mqtt.min.js的协议包，调用api传入三元组进行连接

![93f39fe8-65cb-4de2-a4d0-b26619c67ac0](file:///C:/Users/SHARK/Pictures/Typedown/93f39fe8-65cb-4de2-a4d0-b26619c67ac0.png)

![8d1875de-5860-43a2-85b7-bb493fcf510d](file:///C:/Users/SHARK/Pictures/Typedown/8d1875de-5860-43a2-85b7-bb493fcf510d.png)

可以看到已经接收到了数据

![23831f61-5e20-41ce-8811-c98c61be4fba](file:///C:/Users/SHARK/Pictures/Typedown/23831f61-5e20-41ce-8811-c98c61be4fba.png)

![0c70f895-fd46-4421-88f2-a50d7a9dd9f7](file:///C:/Users/SHARK/Pictures/Typedown/0c70f895-fd46-4421-88f2-a50d7a9dd9f7.png)

![f988f783-81fd-423d-b968-1d4852c8deb0](file:///C:/Users/SHARK/Pictures/Typedown/f988f783-81fd-423d-b968-1d4852c8deb0.png)

在日志里面也可查看相关内容

![882ca30a-0e5f-49ee-a406-0cb24ea64366](file:///C:/Users/SHARK/Pictures/Typedown/882ca30a-0e5f-49ee-a406-0cb24ea64366.png)

进行指令下发

![6bb7dc35-b7a6-4298-b442-b877830fe3c3](file:///C:/Users/SHARK/Pictures/Typedown/6bb7dc35-b7a6-4298-b442-b877830fe3c3.png)

![c8815aa9-9d02-42cd-80b9-06fbb6df3f45](file:///C:/Users/SHARK/Pictures/Typedown/c8815aa9-9d02-42cd-80b9-06fbb6df3f45.png)






