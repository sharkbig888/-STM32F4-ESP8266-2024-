
#ifndef __SYS_H__
#define __SYS_H__

#include "stm32f4xx.h"

// λ�������ĺ궨�壬ֱ��ʹ�����ṩ��BIT_ADDR��
#define BIT_ADDR(byte_offset,bitnum)  (volatile unsigned long*)(0x42000000 + (byte_offset * 32) + (bitnum * 4))

// ����GPIOB�Ĵ�����λ����������ַ
#define GPIOA_OCTL_OFFSET ((GPIOA_BASE + 0x14) - 0x40000000)
#define GPIOB_OCTL_OFFSET ((GPIOB_BASE + 0x14) - 0x40000000)
#define GPIOC_OCTL_OFFSET ((GPIOC_BASE + 0x14) - 0x40000000)
#define GPIOD_OCTL_OFFSET ((GPIOD_BASE + 0x14) - 0x40000000)
#define GPIOE_OCTL_OFFSET ((GPIOE_BASE + 0x14) - 0x40000000)
#define GPIOF_OCTL_OFFSET ((GPIOF_BASE + 0x14) - 0x40000000)
#define GPIOG_OCTL_OFFSET ((GPIOG_BASE + 0x14) - 0x40000000)

#define GPIOA_ISTAT_OFFSET ((GPIOA_BASE + 0x10) - 0x40000000)
#define GPIOB_ISTAT_OFFSET ((GPIOB_BASE + 0x10) - 0x40000000)
#define GPIOC_ISTAT_OFFSET ((GPIOC_BASE + 0x10) - 0x40000000)
#define GPIOD_ISTAT_OFFSET ((GPIOD_BASE + 0x10) - 0x40000000)
#define GPIOE_ISTAT_OFFSET ((GPIOE_BASE + 0x10) - 0x40000000)
#define GPIOF_ISTAT_OFFSET ((GPIOF_BASE + 0x10) - 0x40000000)
#define GPIOG_ISTAT_OFFSET ((GPIOG_BASE + 0x10) - 0x40000000)


// ��������������
#define PAin(n)     *(BIT_ADDR(GPIOA_ISTAT_OFFSET,n))   // PA����
#define PBin(n)     *(BIT_ADDR(GPIOB_ISTAT_OFFSET,n))   // PB����
#define PCin(n)     *(BIT_ADDR(GPIOC_ISTAT_OFFSET,n))   // PC����
#define PDin(n)     *(BIT_ADDR(GPIOD_ISTAT_OFFSET,n))   // PD����
#define PEin(n)     *(BIT_ADDR(GPIOE_ISTAT_OFFSET,n))   // PE����
#define PFin(n)     *(BIT_ADDR(GPIOF_ISTAT_OFFSET,n))   // PF����
#define PGin(n)     *(BIT_ADDR(GPIOG_ISTAT_OFFSET,n))   // PG����

#define PAout(n)    *(BIT_ADDR(GPIOA_OCTL_OFFSET,n))    // PA���
#define PBout(n)    *(BIT_ADDR(GPIOB_OCTL_OFFSET,n))    // PB���
#define PCout(n)    *(BIT_ADDR(GPIOC_OCTL_OFFSET,n))    // PC���
#define PDout(n)    *(BIT_ADDR(GPIOD_OCTL_OFFSET,n))    // PD���
#define PEout(n)    *(BIT_ADDR(GPIOE_OCTL_OFFSET,n))    // PE���
#define PFout(n)    *(BIT_ADDR(GPIOF_OCTL_OFFSET,n))    // PF���
#define PGout(n)    *(BIT_ADDR(GPIOG_OCTL_OFFSET,n))    // PG���

#endif
