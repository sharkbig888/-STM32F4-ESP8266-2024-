#ifndef __TIMER_H
#define __TIMER_H
#include "stm32f4xx.h"                  // Device header
#include <board.h>

void Timer_Init(uint16_t arr,uint16_t psc);
void Set_Compare(uint16_t compare);
void pwm_breathing_lamp(void);
void Timer2_Init(void);
#endif
