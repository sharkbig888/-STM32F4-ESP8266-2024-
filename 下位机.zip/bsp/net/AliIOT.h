#ifndef __ALIIOT_H
#define __ALIIOT_H

#include "stm32f4xx.h"



																																					//�����������˿ڣ��̶�1883
#define CLIENTID				"k19g7lmaIxi.device1|securemode=2,signmethod=hmacsha256,timestamp=1729082498564|"	//�����¼������
#define PASSWD					"f1ccadbec0cc8c82175dbe3d7275fd2658e2bf443ffc78c1954d91e88d97409d"										//�ͻ���ID
#define USERNAME				"device1&k19g7lmaIxi"

_Bool AliIOT_Link(void);
void AliIOT_Subscribe(const char *topics[], unsigned char topic_cnt);
void ALiIOT_Publish(const char *topic, const char *msg);
void ALiIOT_RevPro(unsigned char *cmd);
#endif
