#ifndef __KEY_H
#define __KEY_H

#include "stm32f4xx.h"                  // Device header

#define KEY_RCC							RCC_AHB1Periph_GPIOE
#define KEY0_GPIO_PORT                  GPIOE
#define KEY0_GPIO_PIN                   GPIO_Pin_8

#define KEY1_GPIO_PORT                  GPIOE
#define KEY1_GPIO_PIN                   GPIO_Pin_10

#define KEY0			GPIO_ReadInputDataBit(KEY0_GPIO_PORT,KEY0_GPIO_PIN)
#define KEY1    		GPIO_ReadInputDataBit(KEY1_GPIO_PORT,KEY1_GPIO_PIN)

#define KEY0_PRES    1              /* KEY0���� */
#define KEY1_PRES    2              /* KEY1���� */
void Key_Init(void);
uint8_t key_scan(uint8_t mode);
#endif
