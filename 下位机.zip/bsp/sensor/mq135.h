
#ifndef _MQ135_H_
#define _MQ135_H_

#include "stm32f4xx.h"


#define RCC_MQ135_GPIO_AO    RCC_AHB1Periph_GPIOC
#define RCC_MQ135_GPIO_DO    RCC_AHB1Periph_GPIOC

#define RCC_MQ135_ADC        RCC_APB2Periph_ADC1


#define PORT_ADC             ADC1
#define CHANNEL_ADC          ADC_Channel_10

#define PORT_MQ135_AO        GPIOC
#define GPIO_MQ135_AO        GPIO_Pin_0

#define PORT_MQ135_DO        GPIOC
#define GPIO_MQ135_DO        GPIO_Pin_3

 //��������
#define SAMPLES         30

extern uint16_t mq_value;
void ADC_MQ135_Init(void);

unsigned int Get_MQ135_Percentage_value(void);
char Get_MQ135_DO_value(void);

#endif
