#ifndef __WS2812_H
#define __WS2812_H

#include "stm32f4xx.h"                  // Device header



#define LED_NUM     4   // LED������
#define RGB_BIT     24   // ÿ������24bit��RGB���ݣ����ΰ�G R B����

#define RESET_WORD  10    // �ڴ���RGB����ǰ����һ�ε͵�ƽ
#define DUMMY_WORD  10    // �ڴ���RGB���ݺ󱣳�һ�ε͵�ƽ

#define TIMING_0    22   // T0H(24%) = 1.25us * (22 / 90) = 0.30us, T0L(76%) = 1.25 - 0.30 = 0.95us 
#define TIMING_1    68   // T1H(76%) = 1.25us * (68 / 90) = 0.95us, T1L(24%) = 1.25 - 0.95 = 0.30us 

/* GPIO */
#define WS2813_RCC_CLK_ENABLE                RCC_APB1PeriphClockCmd
#define WS2813_RCC_CLK_PORT               	 RCC_AHB1Periph_GPIOC
#define WS2813_GPIO_PIN                      GPIO_Pin_6
#define WS2813_GPIO_PORT                     GPIOC

/* TIM */
#define WS2813_TIM_RCC_CLK_ENABLE            RCC_APB1PeriphClockCmd
#define WS2813_TIM_RCC_CLK_PORT              RCC_APB1Periph_TIM3
#define WS2813_TIMX                          TIM3
#define TIM_OCXInit                          TIM_OC1Init
#define TIM_OCXPreloadConfig                 TIM_OC1PreloadConfig

/* DMA */
#define WS2813_DMA_RCC_CLK_ENABLE            RCC_AHB1PeriphClockCmd
#define WS2813_DMA_RCC_CLK_PORT              RCC_AHB1Periph_DMA1
#define WS2813_DMA_CHANNELX                  DMA1_Channe5
#define TIMX_CCR1_Address                    (uint32_t)&TIM3->CCR1//��ӦTIM��ͨ��
#define	DMA_STREAM_FLAG						 DMA_FLAG_TCIF4
#define	DMA_STREAM							 DMA1_Stream4
#define TIM_DMA_CCX                          TIM_DMA_CC1//��ӦTIM��ͨ��

void WS2813_Init(void);
void WS2813_Display(uint8_t (*led_buf)[3], uint8_t led_num);

void WS2813_RandomBright(void);
void WS2813_RedBreathe(void);
void WS2813_GreenBreathe(void);
void WS2813_BlueBreathe(void);
void WS2813_AllOn(void);
void WS2813_AllOff(void);
#endif
