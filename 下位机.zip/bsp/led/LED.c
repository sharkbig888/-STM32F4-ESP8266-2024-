#include "LED.H"
#include "sys.h"
void LED_Init(void)
{
	
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD,ENABLE);
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Pin=GPIO_Pin_14|GPIO_Pin_15;
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_OUT;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_100MHz;
	GPIO_InitStruct.GPIO_OType=GPIO_OType_PP;
	GPIO_InitStruct.GPIO_PuPd=GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOD,&GPIO_InitStruct);
	PDout(14)=1;
	PDout(15)=1;
}
void LED_ON(uint8_t pin)
{
	PDout(pin)=0;
}
void LED_OFF(uint8_t pin)
{
	PDout(pin)=1;
}
void LED_Turn(uint8_t pin)
{
	if(PDin(pin)==SET)
	{
		PDout(pin)=0;
	}
	else
	{
		PDout(pin)=1;
	}
}
