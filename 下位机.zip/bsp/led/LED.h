#ifndef __LED_H
#define __LED_H
#include "stm32f4xx.h"                  // Device header


#define LED1    		GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_14)
#define LED2    		GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_15)
void LED_Init(void);
void LED_ON(uint8_t pin);
void LED_OFF(uint8_t pin);
void LED_Turn(uint8_t pin);
#endif
